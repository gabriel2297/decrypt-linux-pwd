# Universidad de Costa Rica
### PF3893 - Seguridad aplicada a infraestructura | decrypt-linux-pwd
Estudiantes: 
- Jean Carlo Mata Serrano (B89880)
- Gabriel Umaña Frías (C09913)

### Uso
1. Clone este repositorio a su computadora.
2. Agregue diccionarios de contraseñas. Puede encontrar ejemplos aqui https://github.com/danielmiessler/SecLists/tree/master/Passwords
3. Ejecute `python3 main.py` e ingrese el hash a desencriptar.